package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetroTicketBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(MetroTicketBookingApplication.class, args);
	}

}
